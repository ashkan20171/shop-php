$( function()
{
    $( '.anyClass_01' ).jCarouselLite(
    {
        vertical: true,
        visible:  2,
        auto:     2500,
        speed:    1000,
        scroll:   1,
		btnPrev: '.previous_01',
		btnNext: '.next_01'
    });
});
