﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>

<body>
<div class="body">
<ul id="iconbar">
<li class="home"><a href="index.php">صفحه اصلی  </a></li>


<li><a href="register.php">ثبت نام </a></li>
<li><a href="adminlogin.php">ورود مدیر </a></li>
<li><a href="tamas.php">تماس با ما </a></li>
<li><a href="about.php">درباره ما </a></li>
</ul>

</div>
</body>
</html>
